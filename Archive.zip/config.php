<?php
// Configuration for Momentum
return [
    // Add your OpenAI API Key here
    'OPENAI_API_KEY' => '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',
];
